import javax.swing.*;
import java.awt.*;
  
class ProgressBarExample extends JFrame
{    
	JProgressBar jb;    
	int i=0,num=0;  
	ImageIcon i1;
   	JLabel l;
	ProgressBarExample()
	{    
		i1 = new ImageIcon("images//voting.jpg");
		l = new JLabel(i1);
		add(l);
		setLayout(null); 

		jb=new JProgressBar(0,2000);    
		jb.setBounds(40,140,320,30);         
		jb.setValue(0);    
		jb.setStringPainted(true);    
		add(jb);    
		setSize(i1.getIconWidth(),i1.getIconHeight());   
		l.setBounds(1,1,i1.getIconWidth(),i1.getIconHeight());
 
		
setLocation(
(Toolkit.getDefaultToolkit().getScreenSize().width-getWidth())/2,
(Toolkit.getDefaultToolkit().getScreenSize().height-getHeight())/2
);

 	
	}    
	public void iterate()
	{    
		while(i<=3000)
		{    
  			jb.setValue(i);    
  			i=i+20;    
  			try
			{
			Thread.sleep(50);
			}
			catch(Exception e)
			{}    
		} 
		this.dispose(); 
		new login();
		  
	}    
	public static void main(String[] args) 
	{    
    		ProgressBarExample m=new ProgressBarExample();    
    		m.setVisible(true);    
    		m.iterate(); 
	}    
}  